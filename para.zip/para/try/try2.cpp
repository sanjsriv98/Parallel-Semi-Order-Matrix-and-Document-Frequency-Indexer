// Solution by Arka Talukdar

#include <stdio.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include <mpi.h>
#include <stdlib.h>
#include <vector>
#define UPPER_BOUND 100
#define MODE 1  // 0 to forsake CL-ARG
#define PRINT 0 // 1 to print primes.
using namespace std;


int max(long a, long b){
    return  (a > b) ? a : b ;
}

int main(int argc, char *argv[]) {
    int id, p, root = 0;
    int n, dprime;
    unsigned int i;
    long ptr;
    long n_hi, n_lo = 1, limit;
    long prime, start, count = 0, total_count = 0;
    double wtime;
    char **end;

    // setting limit
    if (argc > 0 && MODE == 1)
        limit = (long)pow(10,atoi(argv[1]));
    else
        limit = UPPER_BOUND; /*setting upper bound */

    long lsqrt = (long)ceil(sqrt(limit));

    MPI_Init(NULL, NULL);
    MPI_Comm_size(MPI_COMM_WORLD, &p);
    MPI_Comm_rank(MPI_COMM_WORLD, &id);

    //-------Start of timer -------
    if (id == 0)
    wtime = MPI_Wtime();

    // ---- handling larger cases ----
    if (lsqrt < (long)ceil(limit / p * 1.0)) {

        // ------- create arrays ------
        if (id != p - 1)
            n_hi = (long)(limit / p) * (id + 1);
        else
            n_hi = limit;
        if (id == root)
            n_lo = 2;
        else
            n_lo = (long)(limit / p) * id;

        // char *arr = (char *)calloc((n_hi - n_lo), sizeof(char));
        vector<bool> arr((n_hi - n_lo));

        char *sarr = (char *)calloc((lsqrt + 1), sizeof(char));

        ptr = n_lo;
        prime = 2;

        long llsqrt = ceil(sqrt(lsqrt));

        while(1){
            while (prime <= llsqrt && sarr[prime] == 1)
                prime ++;
            for (i = prime * prime; i <= lsqrt; i += prime)
                sarr[i] = 1;
            prime ++;
            if(prime > llsqrt) break;
        }

        prime = 2;

        while (1) {

            while(sarr[prime] == 1 && prime <= lsqrt)
                prime ++;
            if(prime > lsqrt) break;

            // eliminate multiples of prime in n_lo to n_hi
            start = (long)ceil((n_lo * 1.0) / prime) * prime;
            
            if (id == root)
                start += prime;

            dprime = 2 * prime;
            
            if (prime == 2) {
                for (i = start - n_lo; i < n_hi - n_lo; i += prime){
                    arr[i] = true;
                }
            } else if (start % 2 == 0) {
                start += prime;
                for (i = max(start, prime*prime) - n_lo ; i < n_hi - n_lo; i += dprime){
                    arr[i] = true;
                }
            } else {
                for (i = max(start, prime*prime) - n_lo ; i < n_hi - n_lo; i += dprime){
                    arr[i] = true;
                }
            }
            prime += 1;
        }

        long subdomain_size;
        if (id == p - 1)
            subdomain_size = limit - n_lo;
        else
            subdomain_size = n_hi - n_lo;


        int i, count = 0, total_count = 0;
        for(i = 0; i < subdomain_size; i ++){
            if(arr[i]){
                count += 1;
            }
        }

        // int *rcounts, *dsply;
        // if (id == root) {
        //     rcounts = (int *)calloc(p, sizeof(int));
        //     dsply = (int *)calloc(p, sizeof(int));
        //     int i, nh, nl, tc = 0;
        //     for(i=0; i < p; i ++){
        //         if (i != p - 1)
        //             nh = (long)(limit / p) * (i + 1);
        //         else
        //             nh = limit;
        //         if (i == root)
        //             nl = 2;
        //         else
        //             nl = (long)(limit / p) * i;
                
        //         dsply[i] = tc;
        //         rcounts[i] = (nh - nl);
        //         tc += rcounts[i];
        //     }
        // }

        int *rcounts, *dsply;
        if (id == root) {
            rcounts = (int *)calloc(p, sizeof(int));
            dsply = (int *)calloc(p, sizeof(int));
        }
        MPI_Gather(&count, 1, MPI_INT, rcounts, 1, MPI_INT, root, MPI_COMM_WORLD);

        if (id == root) {
            for (i = 0; i < p; i++) {
            dsply[i] = total_count;
            total_count += rcounts[i];
            // printf("Process %d : %d  ..  %d \n", i, rcounts[i], dsply[i]);
            }
        }

        long k = 0;


        long *primes = (long *)malloc(count * sizeof(long));
        for (i = 0; i < subdomain_size; i++) {
            if(arr[i]){
                primes[k] = i + n_lo;
                k++;
            }
        }

        long *all_primes;
        if (id == root)
            all_primes = (long *)calloc(total_count, sizeof(long));
        
        // vector<bool> arr((n_hi - n_lo));
        
        // vector<bool> all_primes;
        // if(id == root)
        //     all_primes.resize((limit - 2));

        // MPI_Gatherv(&arr, (n_hi - n_lo), MPI::BOOL, &all_primes, rcounts, dsply, MPI::BOOL, root, MPI_COMM_WORLD);

        // int total_count = 0;
        // if(id == root){
        //     long i;
        //     for(i=0; i< limit - 2; i++){
        //         if (!all_primes[i]){
        //             total_count += 1;
        //         }
        //     }
        // }
        MPI_Gatherv(primes, count, MPI_LONG, all_primes, rcounts, dsply, MPI_LONG,
                    root, MPI_COMM_WORLD);
        
        // Uncomment the following code to print all the primes.
        if(PRINT == 1 ){
            for (i = 0; i < total_count; i++) {
                printf("%ld\n", all_primes[i]);    
            }
        }
        if (id == root) {
            wtime = MPI_Wtime() - wtime;
            printf("         N        Pi          Time\n");
            printf("  %10ld %10d  %16f\n", limit, total_count, wtime);
        }
        //  free(arr);
    } 

  else {
    if (id == 0) {

      char *arr = (char *)calloc((limit - 1), sizeof(char));
      ptr = 2;
      while (ptr <= lsqrt) {
        if (arr[ptr] == 0) {
          for (i = 2 * ptr - 2; i <= limit - 2; i += ptr)
            arr[i] = 1;
        }
        ptr += 1;
      }

      for (i = 0; i < limit - 2; i++)
        count += arr[i];
      wtime = MPI_Wtime() - wtime;
      printf("         N        Pi          Time\n");
      printf("  %10ld %10ld  %16f\n", limit, total_count, wtime);
      //  free(arr);
    }
  }

  /*   Terminate MPI. */
  MPI_Finalize();
  return 0;
}
